#pragma once


// CClient

class CClient : public CSocket
{
public:
	CClient();
	virtual ~CClient();
};



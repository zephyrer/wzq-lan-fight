#pragma once

// CServer ����Ŀ��

class CServer : public CSocket
{
public:
	CServer();
	virtual ~CServer();
};



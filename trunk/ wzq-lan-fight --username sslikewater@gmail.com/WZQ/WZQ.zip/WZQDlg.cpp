
// WZQDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "WZQ.h"
#include "WZQDlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif
UINT mutex;


CWZQDlg::CWZQDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CWZQDlg::IDD, pParent),
	m_ServerPort(61325),
	m_SearchPort(6666),
	m_gameStart(false),
	m_clientLength(556.0f)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CWZQDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST1, m_gameList);
	DDX_Control(pDX, ID_SERVER, m_BangButton);
	DDX_Control(pDX, ID_CHALLENGE, m_challenge);
	DDX_Control(pDX, ID_NAME, m_name);
}

BEGIN_MESSAGE_MAP(CWZQDlg, CDialogEx)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_MOUSEMOVE()
	ON_WM_CLOSE()
	ON_WM_ERASEBKGND()
	ON_WM_NCHITTEST()
	ON_WM_SETCURSOR()
	ON_BN_CLICKED(ID_SERVER, &CWZQDlg::OnBnClickedServer)
	ON_BN_CLICKED(ID_CHALLENGE, &CWZQDlg::OnBnClickedChallenge)
	ON_BN_CLICKED(ID_SEARCHGAME, &CWZQDlg::OnBnClickedSearchgame)
END_MESSAGE_MAP()


// CWZQDlg ��Ϣ��������

BOOL CWZQDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// ���ô˶Ի����ͼ�ꡣ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	WZQInit();

	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�

using namespace Gdiplus;
void CWZQDlg::OnPaint()
{
	CRect clientrc;
	GetWindowRect(&clientrc);
	CPaintDC dc(this);
	dc.FillSolidRect((INT)m_clientLength-2,0,(INT)m_clientLength,(INT)m_clientLength,RGB(0,0,0));
	CDialogEx::OnPaint();
}


HCURSOR CWZQDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


CWinThread * m_paintThread;
void CWZQDlg::WZQInit(void)
{
	AfxSocketInit();
	MARGINS margins;
	margins.cxLeftWidth = 0;
	margins.cxRightWidth = 190;
	//margins.cxRightWidth = 90;
	margins.cyTopHeight = 0;
	margins.cyBottomHeight = 0;
	DwmExtendFrameIntoClientArea(GetSafeHwnd(), &margins);
	GdiplusStartupInput gdiplusStartupInput;
    
    GdiplusStartup(&gdiplusToken, &gdiplusStartupInput, NULL);
	m_challenge.hoverImage = Image::FromFile(L"img\\hoverB.png");
	m_challenge.normalImage = Image::FromFile(L"img\\normalB.png");
	m_challenge.activeImage = Image::FromFile(L"img\\activeB.png");
	
	m_BangButton.normalImage = Image::FromFile(L"img\\normalC.png");
	m_BangButton.hoverImage = Image::FromFile(L"img\\hoverC.png");
	m_BangButton.activeImage = Image::FromFile(L"img\\activeC.png");

	bkImage = Image::FromFile(L"img\\prod.jpg");

	nullCur  =  LoadCursor( NULL  , MAKEINTRESOURCE (ID_NULLCUR) ) ;
	arrowCur = LoadCursor(NULL, IDC_UPARROW);
	::SetCursor(nullCur);

	m_gameList.AddString("�����ַ���A");
	m_gameList.AddString("123�����ַ���B");
	m_gameList.AddString("345�����ַ���C");
	m_paintThread = AfxBeginThread(PaintThread,this);

}


void CWZQDlg::GetSocketError(void)
{
	DWORD errorCode = GetLastError();
	CString error="NaN socket error";
	switch(errorCode)
	{
	case WSANOTINITIALISED:
		error = "A successful AfxSocketInit must occur before using this API. ";
			break;

	case WSAENETDOWN:
		error = "The Windows Sockets implementation detected that the network subsystem failed. ";
		break;

	case WSAENOTCONN:
		error = "The socket is not connected. ";
		break;

	case WSAEINPROGRESS:
		error = "A blocking Windows Sockets operation is in progress. ";
		break;

	case WSAENOTSOCK:
		error = "The descriptor is not a socket. ";
		break;

	case WSAEOPNOTSUPP:
		error = "MSG_OOB was specified, but the socket is not of type SOCK_STREAM. ";
		break;

	case WSAESHUTDOWN:
		error = "The socket has been shut down; it is not possible to call Receive on a socket after ShutDown has been invoked with nHow set to 0 or 2. ";
		break;

	case WSAEWOULDBLOCK:
		error = "The socket is marked as nonblocking and the Receive operation would block. ";
		break;

	case WSAEMSGSIZE:
		error = "The datagram was too large to fit into the specified buffer and was truncated. ";
		break;

	case WSAEINVAL:
		error = "The socket has not been bound with Bind. ";
		break;

	case WSAECONNABORTED:
		error = "The virtual circuit was aborted due to timeout or other failure. ";
		break;

	case WSAECONNRESET:
		error = "The virtual circuit was reset by the remote side. ";
		break;
	}
	MessageBox(error);
}


void CWZQDlg::OnMouseMove(UINT nFlags, CPoint point)
{
	m_mouse=point;
	CDialogEx::OnMouseMove(nFlags, point);
}


void CWZQDlg::OnClose()
{
	::TerminateThread((HANDLE)PaintThread,2);
	exit(0);
	GdiplusShutdown(gdiplusToken);
	CDialogEx::OnClose();
}


BOOL CWZQDlg::OnEraseBkgnd(CDC* pDC)
{
	return true;
}


LRESULT CWZQDlg::OnNcHitTest(CPoint point)
{
	RECT rc;
	GetWindowRect(&rc);
	if(point.x-rc.left>556)
		return HTCAPTION;
	else
		return CDialogEx::OnNcHitTest(point);
}


BOOL CWZQDlg::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message)
{
	POINT cp;
	RECT rc;
	GetWindowRect(&rc);
	::GetCursorPos(&cp);
	if(cp.x-rc.left<554&&cp.y-rc.top>26)
		::SetCursor(nullCur);
	else
		::SetCursor(arrowCur);
	return TRUE;
}


void CWZQDlg::OnBnClickedServer()
{
	AfxBeginThread(HostThread,this);
}


void CWZQDlg::OnBnClickedChallenge()
{
	m_gameStart = true;
}


UINT CWZQDlg::PaintThread(LPVOID param)
{
	CWZQDlg* pwd = (CWZQDlg*)param;
	UINT sideLength = 554;
	REAL blockLength = sideLength/15.0F;
	CDC *pdc =pwd->GetDC();
	CBitmap memb;
	memb.CreateCompatibleBitmap(pdc,sideLength,sideLength);
	POINT or = pwd->m_mouse;
	HPEN hp = ::CreatePen(PS_SOLID,8,RGB(255,0,0));
	while(1)
	{
		CDC memdc;
		memdc.CreateCompatibleDC(pdc);
		memdc.SelectObject(memb);
		Graphics gs(memdc.GetSafeHdc());
		gs.SetSmoothingMode(Gdiplus::SmoothingModeAntiAlias);
		gs.SetTextRenderingHint(Gdiplus::TextRenderingHintAntiAlias);
		gs.DrawImage(pwd->bkImage,0,0,sideLength,sideLength);
		gs.FillEllipse(&SolidBrush(Color::Blue),or.x-20,or.y-20,40,40);
		or = pwd->m_mouse;
		pdc->BitBlt(0,0,sideLength,sideLength,&memdc,0,0,SRCCOPY);
		memdc.DeleteDC();
		//Beep(1000,10);
		Sleep(20);
	}
	pwd->ReleaseDC(pdc);
	return 0;
}

UINT CWZQDlg::ReceiveThread(LPVOID param)
{
	CWZQDlg* pwd = (CWZQDlg*)param;
	

	return 0;
}


UINT CWZQDlg::SendThread(LPVOID param)
{
	CWZQDlg* pwd = (CWZQDlg*)param;

	return 0;
}

UINT CWZQDlg::SearchThread(LPVOID param)
{
	CWZQDlg* pwd = (CWZQDlg*)param;
	MsgPack msp;
	CString hostAddr;
	UINT hostPort;
	BOOL broadcast=TRUE;
	msp.type = SEARCH_HOST;
	//pwd->searchSock.Create(0,SOCK_DGRAM);
	//pwd->searchSock.SetSockOpt(SO_BROADCAST,&broadcast,sizeof(BOOL));
	////while(pwd->m_gameStart==false)
	////{
	//	pwd->searchSock.SendTo(&msp,sizeof(MsgPack),pwd->m_SearchPort,"255.255.255.255");
	//	pwd->searchSock.ReceiveFrom(&msp,sizeof(MsgPack),hostAddr,hostPort);
	//	LPSTR serverName = (CHAR*)::malloc(strlen(msp.data.SR.server)+1);
	//	strcpy(serverName,msp.data.SR.server);
	//	pwd->m_gameList.AddString(serverName);
	//	
	////}
	//	pwd->serverSock.Close();
	//	pwd->serverSock.ShutDown();
	CSocket searchSock;
	searchSock.Create(0,SOCK_DGRAM);
	searchSock.SetSockOpt(SO_BROADCAST,&broadcast,sizeof(BOOL));
	searchSock.SendTo(&msp,sizeof(MsgPack),pwd->m_SearchPort,"255.255.255.255");
	searchSock.ReceiveFrom(&msp,sizeof(MsgPack),hostAddr,hostPort);
	LPSTR serverName = (CHAR*)::malloc(strlen(msp.data.SR.server)+1);
	strcpy(serverName,msp.data.SR.server);
	pwd->m_gameList.AddString(serverName);

	searchSock.Close();
	searchSock.ShutDown();
	return 0;
}


UINT CWZQDlg::HostThread(LPVOID param)
{
	CWZQDlg* pwd = (CWZQDlg*)param;
	MsgPack msp;
	CString clientAddr;
	UINT clientPort;
//	pwd->hostSock.Create(pwd->m_SearchPort,SOCK_DGRAM);
////	while(pwd->m_gameStart==false)
//	//{
//		pwd->hostSock.ReceiveFrom(&msp,sizeof(msp),clientAddr,clientPort);
//		if(msp.type == SEARCH_HOST)
//		{
//			MsgPack hostMsg;
//			hostMsg.type = HOST_RESPONSE;
//			CString name="";
//			pwd->m_name.GetWindowTextA(name);
//			strcpy_s(hostMsg.data.SR.server,sizeof(hostMsg.data.SR.server),name);
//			CString a(hostMsg.data.SR.server);
//			hostMsg.data.SR.uesrNum = 1;
//			pwd->hostSock.SendTo(&hostMsg,sizeof(MsgPack),clientPort,clientAddr);
//		}
////	}
//		pwd->hostSock.Close();
	CSocket hostSock;
	hostSock.Create(pwd->m_SearchPort,SOCK_DGRAM);

	hostSock.ReceiveFrom(&msp,sizeof(msp),clientAddr,clientPort);
	if(msp.type == SEARCH_HOST)
	{
		MsgPack hostMsg;
		hostMsg.type = HOST_RESPONSE;
		CString name="";
		//pwd->m_name.GetWindowTextA(name);
		pwd->m_name.GetWindowTextA(hostMsg.data.SR.server,sizeof(hostMsg.data.SR.server));
		//strcpy_s(hostMsg.data.SR.server,sizeof(hostMsg.data.SR.server),name);
		//CString a(hostMsg.data.SR.server);
		hostMsg.data.SR.uesrNum = 1;
		hostSock.SendTo(&hostMsg,sizeof(MsgPack),clientPort,clientAddr);
	}

	hostSock.Close();
	hostSock.ShutDown();
	return 0;
}


void CWZQDlg::OnBnClickedSearchgame()
{
	AfxBeginThread(SearchThread,this);
}

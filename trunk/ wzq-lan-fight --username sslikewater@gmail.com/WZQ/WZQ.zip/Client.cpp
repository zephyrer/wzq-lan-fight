// Client.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "WZQ.h"
#include "Client.h"


// CClient

CClient::CClient()
{

}

CClient::~CClient()
{
}


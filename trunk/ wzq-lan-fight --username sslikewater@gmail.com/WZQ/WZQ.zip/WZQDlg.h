
// WZQDlg.h : ͷ�ļ�
//

#pragma once
#include "afxwin.h"

#include "MyEdit.h"
#include "MyButton.h"
#include "MyListBox.h"

// CWZQDlg �Ի���
class CWZQDlg : public CDialogEx
{
// ����
public:
	CWZQDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_WZQ_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	DECLARE_MESSAGE_MAP()
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg LRESULT OnNcHitTest(CPoint point);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnBnClickedServer();
	afx_msg void OnBnClickedChallenge();
	afx_msg void OnClose();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);

	void WZQInit(void);
private:
	CSocket serverSock;
	CSocket clientSock;
	CSocket hostSock;
	CSocket searchSock;

	CString hostAddrSock;

	UINT m_ServerPort;
	UINT m_SearchPort;

	bool m_gameStart;

	POINT m_mouse;
	ULONG_PTR gdiplusToken;
	HCURSOR nullCur;
	HCURSOR arrowCur;
	FLOAT m_clientLength;
	Gdiplus::Image *bkImage;
	MyListBox m_gameList;
	MyButton m_BangButton;
	MyButton m_challenge;
	static UINT ReceiveThread(LPVOID param);
	static UINT SendThread(LPVOID param);
	static UINT PaintThread(LPVOID param);
	static UINT SearchThread(LPVOID param);
	static UINT HostThread(LPVOID param);
	void GetSocketError(void);

	MyEdit m_name;
public:
	afx_msg void OnBnClickedSearchgame();
};
